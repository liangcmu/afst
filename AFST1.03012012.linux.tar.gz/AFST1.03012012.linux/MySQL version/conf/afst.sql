
CREATE DATABASE IF NOT EXISTS `afst`;
USE afst;
SET FOREIGN_KEY_CHECKS=0;

CREATE TABLE IF NOT EXISTS `case_pattern` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL,
  `seqname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `casenumber` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `pattern_case` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `mark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direction` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `seqname` (`seqname`),
  KEY `mark` (`mark`),
  KEY `direction` (`direction`)
) ENGINE=MyISAM AUTO_INCREMENT=10248 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

CREATE TABLE IF NOT EXISTS `case_pattern_finalseq` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `sid` int(10) NOT NULL,
  `seqname` varchar(255) COLLATE utf8_bin DEFAULT NULL,
  `casenumber` varchar(50) COLLATE utf8_bin DEFAULT NULL,
  `pattern_case` varchar(10) COLLATE utf8_bin DEFAULT NULL,
  `mark` varchar(200) COLLATE utf8_bin DEFAULT NULL,
  `direction` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  `final_start` int(11) DEFAULT NULL,
  `final_end` int(11) DEFAULT NULL,
  `no_final_reason` varchar(45) COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sid` (`sid`),
  KEY `seqname` (`seqname`),
  KEY `mark` (`mark`),
  KEY `direction` (`direction`),
  KEY `case_pattern` (`casenumber`)
) ENGINE=MyISAM AUTO_INCREMENT=10248 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS `feature`;
CREATE TABLE `feature` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_id` int(10) unsigned NOT NULL DEFAULT '0',
  `seq_name` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(45) NOT NULL DEFAULT '',
  `error_number` int(10) unsigned NOT NULL DEFAULT '0',
  `percent` int(10) unsigned NOT NULL DEFAULT '0',
  `start_position` int(10) unsigned NOT NULL DEFAULT '0',
  `end_position` int(10) unsigned NOT NULL DEFAULT '0',
  `direction` varchar(45) NOT NULL DEFAULT '',
  `polyat_position` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seq_id` (`seq_id`),
  KEY `seq_name` (`seq_name`),
  KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `seqbase` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_name` varchar(100) NOT NULL DEFAULT '',
  `sequence` varchar(5000) NOT NULL DEFAULT '',
  `quality` varchar(10000) NOT NULL DEFAULT '',
  `direction` varchar(1) NOT NULL DEFAULT '',
  `high_start` int(10) unsigned DEFAULT NULL,
  `high_end` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seq_name` (`seq_name`)
) ENGINE=InnoDB AUTO_INCREMENT=10248 DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `terminus`;
CREATE TABLE `terminus` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_id` int(10) unsigned NOT NULL DEFAULT '0',
  `seq_name` varchar(100) NOT NULL DEFAULT '',
  `name` varchar(45) NOT NULL DEFAULT '',
  `error_number` int(10) unsigned NOT NULL DEFAULT '0',
  `percent` int(10) unsigned NOT NULL DEFAULT '0',
  `start_position` int(10) unsigned NOT NULL DEFAULT '0',
  `end_position` int(10) unsigned NOT NULL DEFAULT '0',
  `polyat_position` int(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seq_id` (`seq_id`),
  KEY `seq_name` (`seq_name`),
  KEY `name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=8946 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `vector` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_name` varchar(45) NOT NULL DEFAULT '',
  `start_position` int(10) unsigned NOT NULL DEFAULT '0',
  `end_position` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `seq_name` (`seq_name`)
) ENGINE=InnoDB AUTO_INCREMENT=195 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `vector_267_3` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_name` varchar(45) NOT NULL DEFAULT '',
  `start_position` int(10) unsigned NOT NULL DEFAULT '0',
  `end_position` int(10) unsigned NOT NULL DEFAULT '0',
  `vector_start` int(10) unsigned NOT NULL DEFAULT '0',
  `vector_end` int(10) unsigned NOT NULL DEFAULT '0',
  `recatype` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seq_name` (`seq_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `vector_267_5` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `seq_name` varchar(45) NOT NULL DEFAULT '',
  `start_position` int(10) unsigned NOT NULL DEFAULT '0',
  `end_position` int(10) unsigned NOT NULL DEFAULT '0',
  `vector_start` int(10) unsigned NOT NULL DEFAULT '0',
  `vector_end` int(10) unsigned NOT NULL DEFAULT '0',
  `recatype` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `seq_name` (`seq_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;