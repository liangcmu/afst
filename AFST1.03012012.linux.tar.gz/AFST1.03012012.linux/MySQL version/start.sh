echo "AFST is a software tool for Abnormality Filtering and Sequence Trimming for ESTs."
echo "If you encounter a problem using the software tool, please read 'AFST.V1.0.FAQ' for solution."
echo ""
function pause(){
        read -n 1 -p "$*" INP
        if [[ $INP != '' ]] ; then
                echo -ne '\b \n'
        fi
} 
pause 'Press any key to continue...'
chmod -R 777 plugIn/blast/
java -Xmx1024m -jar AFST-gui.jar 

